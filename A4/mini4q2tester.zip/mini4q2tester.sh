# test 1: anagram
./anagram mary ramy
echo "*** expected: Anagram"
# test 2: not an anagram
./anagram bob lary
echo "*** expected: Not an Anagram"
# end of tester
echo "END OF TESTING SCRIPT"

